## Computational Finance Final Exam

##### Professor: Goukasian

Please note that running this final exam requires 

C++ library Eigen: http://eigen.tuxfamily.org/index.php?title=Main_Page

The current CMakeLists.txt points the directory 

```
set(EIGEN_DIR "/Users/paragonhao/Documents/dev/eigen")
```


Helper Functions are found in ```Mutils.h```