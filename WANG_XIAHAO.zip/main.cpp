#include <iostream>
#include "Final_1.h"
#include "Final_2.h"
#include "Final_3.h"
#include "Final_4.h"
#include "Final_5.h"

int main() {
    Qn1::RunQ1();
    Qn2::RunQ2();
    Qn3::RunQ3();
    Qn4::RunQ4();
    Qn5::RunQ5();

    return 0;
}